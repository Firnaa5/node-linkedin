import mongoose from 'mongoose';
import bodyParser from 'body-parser';
import express from 'express';
import routes from './src/routes/empRoutes';

const app = express()
const PORT = 3000;

//mongoose connection
mongoose.Promise = global.Promise;
const dbUrl ="mongodb+srv://root:admin@123@employee-7o95u.mongodb.net/Management?retryWrites=true";

mongoose.connect(dbUrl, { useNewUrlParser: true
});

//bodyParser
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended : true}))

routes(app);

app.get('/', (req, res) =>{
	res.send(`Node server is running on ${PORT}`)
})

app.listen(PORT, () =>{
	console.log(`app is running on ${PORT}`)
})