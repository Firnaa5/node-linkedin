import { addNewEmployee, getEmployee, getEmployeeWithId, updateEmployee, deleteEmployee } from '../controllers/empController';

const routes = (app) => {
	app.route('/employee')

	//get endpoint
	.get(getEmployee)

	//POST endpoint
	.post(addNewEmployee);


	app.route('/employee/:employeeId')
	//get specific request
	.get(getEmployeeWithId)
	// put request
	.put(updateEmployee)
	
	//delete request
	.delete(deleteEmployee);
}


export default routes;