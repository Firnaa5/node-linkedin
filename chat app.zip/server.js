var express = require('express');
var bodyParser = require('body-parser');

var app = express()
var http = require('http').Server(app)
var io = require('socket.io')(http)
var mongoose = require('mongoose')

mongoose.Promise = Promise

var dbUrl = "mongodb+srv://root:admin@123@firnaas-tarae.mongodb.net/test?retryWrites=true"

app.use(express.static(__dirname))
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended : false}))

//schema endpoint for connection with db

var Messages = mongoose.model('Message', {
	name: String,
	message: String
})

/*var messages = [
	{
		name : 'Tim',
		message: 'Hi'
	},
	{
		name : 'Jane',
		message: 'Hello'
	}
	] */

app.get('/messages',(req, res) => {
	Messages.find({}, (err, messages) => {
		res.send(messages)
	})
	
})

app.post('/messages',async (req, res) => {

	try{

		var message = new Messages(req.body)
		console.log(Messages)

		var savedMessage = await message.save()

		var censored = await Messages.findOne({message: 'badword'})

		if(censored)
			await Messages.deleteOne({ _id: censored.id})
		else
			io.emit('message',req.body)
			res.sendStatus(200)

	} catch(error) {

		res.sendStatus(500)
		return console.log(error)

	}
	
})
	

io.on('çonnection', (socket) => {
	console.log('a user is connected')
})

mongoose.connect(dbUrl, { useNewUrlParser: true } ,(err) => {
	console.log('mongo db connection', err)
})

var server = http.listen(3000, () =>{
	console.log('Server is running on port', server.address().port)
})
